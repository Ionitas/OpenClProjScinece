﻿#include "funcs.h"
#include "helpers.h"
int main() {
	cl::Program program = CreateProgram("myDerivateKernel.cl");
	cl::Context context = program.getInfo<CL_PROGRAM_CONTEXT>();
	std::vector<cl::Device> devices = context.getInfo<CL_CONTEXT_DEVICES>();
	auto& device = devices.front();
	cl::CommandQueue queue(context, device);
	std::cout << device.getInfo<CL_DEVICE_NAME>() << std::endl;
	std::ofstream time;
	time.open("times.txt");
	std::ofstream sized;
	sized.open("sizes.txt");


	//int currentSize = 100000;
	//
	//while (currentSize < 10000000) {
	//	settings::VectorArraySize = currentSize;
	

		std::vector <float> gridData = settings::InitGrid1D();
		std::vector <float> funcDataonGrid = settings::InitData1D(settings::t0, gridData);
		cl_int error_ret;
		cl::Buffer gridBuff = CreateInitBuffer(context, gridData, "MAIN FUNC INITBUF");
		cl::Buffer dataBuff = CreateInitBuffer(context, funcDataonGrid, "MAIN FUNC DATABUF");


		std::cout << "Is it stable ? " << (equation::checkStable1D(program, context, gridBuff, settings::tau, settings::a) ? "Yes, < 1/2" : "No, >1/2") << std::endl;
		//std::cout << currentSize << std::endl;
		double avaragetime = 0.0f;
		for (int kk = 0; kk < 4; kk++) {
			
			//std::ofstream myfile;
			//myfile.open("my.txt");

			auto start = std::chrono::system_clock::now();
			cl::Buffer f_z = CreateMixedBuffer(context, "Func");
			cl::Buffer x_z = CreateMixedBuffer(context, "Func");
			cl::Buffer f_zz = CreateMixedBuffer(context, "Func");
			cl::Buffer x_zz = CreateMixedBuffer(context, "Func");
			cl::Buffer du = CreateMixedBuffer(context, "Func");
			cl::Buffer d2u = CreateMixedBuffer(context, "Func");
			cl::Buffer heats = CreateMixedBuffer(context, "Func");
			cl::Buffer step = dataBuff;
			for (int i = 0; i < settings::tsteps; i++) {
				step = equation::steaperHeatEquation(program, context, queue, gridBuff, step, settings::tau, 
					f_z, x_z, f_zz, x_zz, du, d2u, heats);
			}

			//std::vector<float> resultParalel = getFromBuffer(queue, step);
			//for (int it = 0; it < resultParalel.size(); ++it) {
			//	myfile << resultParalel[it] << ",";
			//}
			//
			//myfile.close();


			auto end = std::chrono::system_clock::now();
			std::chrono::duration<double> diff = end - start;
			std::cout << "Time: " << std::setw(9) << diff.count() << std::endl;
			avaragetime += diff.count();
		}
		

		time << avaragetime / 4 << ",";
		//sized << currentSize << ",";



	//	currentSize += 100000;
	//}



	
	return 0;
}
 